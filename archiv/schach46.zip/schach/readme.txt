______________________________________________________________________

********************* Deutsch ****************************************
______________________________________________________________________

Installationshinweise:
----------------------
1. Kopieren Sie die entpackte Datei "Schach.exe" in ein beliebiges Verzeichnis.
2. Nutzen Sie Fernschach mit verschl�sselten Mails, ben�tigen Sie zus�tzlich die Dateien libea32.dll und ssleay32.dll. In diesem Fall kopieren Sie diese Dateien ebenfalls in Ihr Schach-Verzeichnis.
3.Kann auch auf ein USB-Stick kopiert werden.
4.Starten Sie das Programm.
5.Viel Spa�

Deinstallation:
---------------
Sie entfernen das Schachprogramm, indem Sie die Dateien: 
  Schach.exe,
  Schach-Konfig.cfg (Einstellungen) 
und falls vorhanden: 
  libea32.dll, ssleay32.dll (f�r verschl�sselte Mails),
  Schach-Bewert*.html (Bewertungstabelle) und 
  FreewareSchach.pgn (Ihre gesicherten Partien)" l�schen.

Diese Dateien befinden sich nur in einem Verzeichnis.


Rolf Radke
kontakt@freeware-schach.de
http://www.freeware-schach.de

______________________________________________________________________

********************* English ****************************************
______________________________________________________________________

Installation
------------
1. Copy the file "Schach.exe" into any directory.
2. If you like to play telechess with encrypted mails, you need the files "libea32.dll" and "ssleay32.dll". Copy these files to your chess directory.
3. You can also copy it to an USB stick.
4. Start "schach.exe".
5. Have much fun

Uninstall
---------
If you want to uninstall Freeware-Chess: Please delete these files:
  Schach.exe,
  Schach-Konfig.cfg (settings) 
and if exists:
  libea32.dll, ssleay32.dll (for encrypted mails),
  Schach-Bewert*.html (evaluation table) and 
  FreewareSchach.pgn (Your saved games)

You will find these files in only one directory.


Rolf Radke
kontakt@freeware-schach.de
http://www.freeware-schach.de/eindex.html

