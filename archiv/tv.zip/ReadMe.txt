T U R N I E R V E R W A L T U N G    F�R  SCHACHTURNIERE
========================================================

Autor:  Hans-J�rgen Werner
        hj.werner@t-online.de

Dieses Programm zur Verwaltung von Schachturnieren ist ein
Public-Domain-Programm und darf kostenlos weitergegeben werden!

Das Programm kann max. 39 Runden und 254 Spieler verwalten.

Neue Versionen k�nnen �ber die Homepage des Schach-Klub Freising
bezogen werden: http://www.sk-freising.de

Die Auslosung verwendet NICHT den Fide-Algorithmus!


Das Programm ist f�r Windows98 und Windows NT 4.0 entwickelt
und auch unter den neueren Windows-Versionen lauff�hig
(getestet mit Windows XP).

Bei Windows95 gibt es Einschr�nkungen:
windows(.95)\system\oleaut32.dll  mit Datum 19.11.97 funktioniert.
windows(.95)\system\oleaut32.dll  mit Datum 24.08.95 funktioniert nicht!
Au�erdem werden die Dateien OLEPRO32.DLL, MFC42.DLL und MSVCRT.DLL ben�tigt.
Meistens sind diese Dateien im System-Verzeichnis bereits vorhanden,
sie k�nnen aber auch �ber den Autor bezogen werden.

Als Grafikaufl�sung gen�gt 640*480, jedoch wird eine bessere
Aufl�sung empfohlen.

Benutzer der �lteren DOS-Version der Turnierverwaltung sollten die
Endung vorhandener Turnier-Dateien auf ".TV" erg�nzen; die Daten
sind inklusive der deutschen Umlaute kompatibel.
Das Rutschsystem funktioniert erst ab Version 4.10.

Die DWZ-Zahlen werden bei der Auslosung nicht ber�cksichtigt!


Versionshinweise
----------------
Version 4.12    11/2004: Mannschaftskampf-Statistik:
			    - L�schen eines Teilnehmers korrigiert (M.-Statistik!)

Version 4.11    11/2004: 1) Tabelle bei Schweizer System:
			    - wenn in der letzten Runde noch keine Partie gespielt
			      wurde, erscheint eine Abfrage, ob die Wertung diese
			      Runde ber�cksichtigen soll;
			      falls nicht, wird "Stand nach x Runden" in der 
			      ersten Zeile der Tabelle eingetragen.
			 2) Tabelle:
			    - Ausdruck von Runden und Tabelle korrigiert.
			 3) Tabellenbreite bei HTML-Datei ge�ndert.
			 4) Mannschaftskampf-Statistik:
			    - Gesamt-Brettpunkte korrigiert
			      (0:x ohne Spieler auf Brett 1 wurde falsch gez�hlt)
			    - Einf�gen eines Teilnehmers korrigiert (M.-Statistik!)
			    - Ausdruck der Mannschaftsstatistik korrigiert

Version 4.10	04/2003: neu: Rutschsystem;
			 Einf�gen bei Mannschaftskampfstatistik korrigiert.

Version 4.03	02/2002: Name "spielfrei" statt leerem Namen;
			 bei ausgeschiedenem Spieler Ergebnis " " statt "_".

Version 4.02	01/2001: neu: mit Speicherung im RTF-Format f�r Word;
                         diverse �berarbeitungen zur einfacheren Eingabe.

Version 4.01	�berarbeitete Version vom 09.11.2000

Version 4.00	Erstversion, eingesetzt beim Domstadt-Duo 2000 in Freising

 

F�r die Bedienung des Programms werden Grundkenntisse �ber Windows-Bedienung
vorausgesetzt. Mit den f�nf Dialogboxen sollte sich jeder Bediener schnell zurechtfinden:

1. Modus:
	Realisiert sind bis jetzt:
	Rundensystem / Doppelrundensystem / Schweizer System / Rutschsystem

	Maximal drei der folgenden Wertungssysteme k�nnen eingestellt werden:
	* Sonneborg-Berger-Wertung (f�r Rundensystem)
	* Buchholz-Wertung (f�r Schweizer System)
	* Buchholz-Streichwertung 1 (schlechtestes Ergebnis gestrichen)
	* Buchholz-Streichwertung 2 (schlechtestes und bestes Ergebnis gestrichen)
	* Gewinnpartien-Wertung

2. Teilnehmer:
	Folgende Felder stehen zur Verf�gung:
	- Name      (23-stellig)    (Vereinsname bei Mannschaften)
	- Verein    (18-stellig)    (frei verwendbar)
	- DWZ/Elo   (13-stellig)    (frei verwendbar)
	- Zusatz    ( 1-stellig)    (Ausgeschieden bzw. Platz bei Stichkampf) 

3. Auslosung:
	* Computerauslosung einer neuen Runde
	* manuelle Eingabe
	* Computerauslosung der fehlenden Paarungen nach einer manuellen Eingabe
	* Pr�fung der Auslosung
	  - Einmaligkeit des Gegners
	  - Anzahl der Farbwiederholung sollte zwei nicht �berschreiten.
	  - Pr�fung der zuvor eingegebenen Ergebnisse
	    Bei Fehlerhaftigkeit ist die Runde wieder zu l�schen, das
	    Ergebnis zu verbessern und erneut auszulosen.
	  - Punktedifferenz bei zwei Gegnern im Schweizer System.
	    Diese sollte 1 Punkt nicht �berschreiten, was bei
	    wenigen Teilnehmern schwer zu vermeiden ist.
	Die DWZ wird bei der Auslosung nicht ber�cksichtigt!     

4. Ergebnisse
	* Anzeige und Eingabe der fehlenden Ergebnisse
	* Anzeige und Eingabe aller Ergebnisse
	Das Ergebnis kann mit Buttons oder in Eingabefelder eingegeben werden.
		0	verloren
		0.5	unentschieden
		0,5	unentschieden  (wird in 0.5 umgewandelt)
		0k	kampflos verloren
		1k	kampflos gewonnen
		H	H�ngeparte (oder auch HP)

5. Tabelle
	* Anzeige der Tabelle (Fortschritts- oder Rundentabelle)
	* Ausdruck von Paarungen und der Tabelle
	* Speichern von Paarungen und der Tabelle als TEXT- oder HTML-Datei
	  (Image und Hintergrund sind in der Datei TV.INI einstellbar;
	  die Datei wird bei Speichern automatisch angelegt; 
	  dort ist auch ein Beispiel enthalten.)

Viel Erfolg!
